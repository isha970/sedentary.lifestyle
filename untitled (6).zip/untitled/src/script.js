document.addEventListener('DOMContentLoaded', function() {

    // --- FAQ Accordion ---
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
        const questionButton = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');

        questionButton.addEventListener('click', () => {
            // Check if the current item is already active
            const isActive = item.classList.contains('active');

            // Optional: Close all other items
            // faqItems.forEach(otherItem => {
            //     if (otherItem !== item) {
            //         otherItem.classList.remove('active');
            //         otherItem.querySelector('.faq-answer').style.maxHeight = null;
            //          otherItem.querySelector('.faq-answer').style.padding = '0 25px';
            //     }
            // });

            // Toggle the current item
            if (isActive) {
                item.classList.remove('active');
                answer.style.maxHeight = null;
                 answer.style.padding = '0 25px'; // Collapse padding too
            } else {
                item.classList.add('active');
                // Set max-height to scrollHeight for dynamic content height
                answer.style.maxHeight = answer.scrollHeight + "px";
                answer.style.padding = '20px 25px'; // Expand padding
            }
        });
    });

    // --- Update Copyright Year ---
    const currentYearSpan = document.getElementById('current-year');
    if (currentYearSpan) {
        currentYearSpan.textContent = new Date().getFullYear();
    }

    // --- Optional: Smooth scroll for internal links (if not handled by CSS) ---
    // document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    //     anchor.addEventListener('click', function (e) {
    //         e.preventDefault();
    //         const targetId = this.getAttribute('href');
    //         const targetElement = document.querySelector(targetId);
    //         if(targetElement) {
    //             targetElement.scrollIntoView({
    //                 behavior: 'smooth'
    //             });
    //         }
    //     });
    // });


    // --- Optional: Add active class to nav links on scroll ---
    // const sections = document.querySelectorAll('section[id]');
    // const navLi = document.querySelectorAll('header nav ul li a');

    // window.addEventListener('scroll', () => {
    //     let current = '';
    //     sections.forEach(section => {
    //         const sectionTop = section.offsetTop;
    //         // Adjust offset as needed based on header height
    //         const sectionHeight = section.clientHeight;
    //         if (pageYOffset >= (sectionTop - sectionHeight / 3) ) {
    //             current = section.getAttribute('id');
    //         }
    //     });

    //     navLi.forEach(a => {
    //         a.classList.remove('active');
    //         if (a.getAttribute('href') === `#${current}`) {
    //             a.classList.add('active');
    //         }
    //     });
    // });


}); // End DOMContentLoaded